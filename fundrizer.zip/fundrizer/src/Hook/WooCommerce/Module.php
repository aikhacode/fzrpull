<?php

if (!defined('ABSPATH')) {
	exit;
}

add_action('init', function () {
	if(!class_exists('WC_Product_Fundraising')){
		class WC_Product_Fundraising extends \WC_Product
		{
			public $product_type;

			public function __construct($product)
			{
				parent::__construct($product);
				$this->product_type = 'fundraising'; // Dynamic property
			}
		}
	}
});

add_filter('woocommerce_is_purchasable', function ($purchasable, $product) {
	if ($product->get_type() === 'fundraising') {
		$purchasable = true;
	}

	return $purchasable;
}, 10, 2);

add_action('woocommerce_order_status_completed', 'frzr_woo_email_order_completed', 10, 1);
function frzr_woo_email_order_completed($order_id)
{
	if (frzr_woo_is_fundraising_product($order_id)) {
		add_filter('woocommerce_email_enabled_customer_completed_order', function ($yesno, $object) {
			return false;
		}, 10, 2);
		$email_new_order = WC()->mailer()->get_emails()['FRZR_Contribution_Completed_Email'];
		$email_new_order->trigger($order_id);
	}
}

add_action('woocommerce_order_status_pending', 'frzr_woo_email_new_order', 10, 1);
add_action('woocommerce_order_status_on-hold', 'frzr_woo_email_new_order', 10, 1);
add_action('woocommerce_order_status_processing', 'frzr_woo_email_new_order', 10, 1);
function frzr_woo_email_new_order($order_id)
{
	if (frzr_woo_is_fundraising_product($order_id)) {
		add_filter('woocommerce_email_enabled_new_order', function ($yesno, $object) {
			return false;
		}, 10, 2);
		add_filter('woocommerce_email_enabled_customer_processing_order', function ($yesno, $object) {
			return false;
		}, 10, 2);
		add_filter('woocommerce_email_enabled_customer_on_hold_order', function ($yesno, $object) {
			return false;
		}, 10, 2);

		$email_new_order = WC()->mailer()->get_emails()['FRZR_New_Contribution_Email'];
		$email_new_order->trigger($order_id);
	}
}

function frzr_woo_is_fundraising_product($order_id)
{
	$order = wc_get_order($order_id);
	if (!$order || !$order->get_items()) {
		return;
	}

	$has_fundraising_product = false;
	foreach ($order->get_items() as $item) {
		$product = $item->get_product();
		if ($product && $product->is_type('fundraising')) {
			$has_fundraising_product = true;
			break;
		}
	}

	return $has_fundraising_product;
}

add_filter('woocommerce_email_classes', function ($email_classes) {
	require_once FUNDRIZER_PATH . 'src/Hook/WooCommerce/Notification/class-new-contribution-email.php';
	require_once FUNDRIZER_PATH . 'src/Hook/WooCommerce/Notification/class-contribution-completed-email.php';

	$email_classes['FRZR_New_Contribution_Email'] = new FRZR_New_Contribution_Email();
	$email_classes['FRZR_Contribution_Completed_Email'] = new FRZR_Contribution_Completed_Email();

	return $email_classes;
});


add_action('woocommerce_checkout_update_order_meta', function ($order_id, $posted) {

	if (frzr_woo_is_fundraising_product($order_id)) {
		$order = wc_get_order($order_id);
		$order->update_meta_data('fundraising', 'true');
		$order->save();
	}
}, 10, 2);
