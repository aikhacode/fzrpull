<?php

namespace Fundrizer\Hook\WooCommerce;

if (!defined('WPTEST')) {
	defined('ABSPATH') or die("Direct access to files is prohibited");
}

class Front
{
	use \Fundrizer\SingletonTrait;

	public function __construct()
	{
		add_action('woocommerce_before_calculate_totals', array($this, 'custom_fundraising_product_price'));
		// add_action('woocommerce_checkout_create_order_line_item', array($this, 'save_custom_meta_to_order_item'), 10, 4);
		add_action('wp_footer', array($this, 'add_custom_scripts'));
	}

	public function custom_fundraising_product_price($cart_object)
	{
		foreach ($cart_object->cart_contents as $key => $value) {
			if (isset($value['custom_data']['fundraising_amount'])) {
				$value['data']->set_price($value['custom_data']['fundraising_amount']);
			}
		}
	}

	// public function save_custom_meta_to_order_item($item, $cart_item_key, $values, $order)
	// {
	// 	$item->add_meta_data('fundraising', true);
	// }

	public function add_custom_scripts()
	{
?>
		<script type="text/javascript">
			document.addEventListener('DOMContentLoaded', function() {
				var buttons = document.querySelectorAll('.fundrizer-button');

				buttons.forEach(function(button) {
					button.addEventListener('click', function(event) {
						event.preventDefault();

						var amountBox = document.getElementById('amount-box');
						var productId = amountBox.getAttribute('data-product-id');

						// Input Validation
						if (!amountBox.value) {
							amountBox.style.border = "1px solid red";
							amountBox.value = '';
							return false;
						} else {
							amountBox.style.border = "";
						}

						// Minimum JS Validation
						var enteredValue = parseFloat(amountBox.value.replace(/,/g, ''));
						var minValue = parseFloat(amountBox.getAttribute('min'));

						if (enteredValue < minValue) {
							amountBox.style.border = "1px solid red";
							amountBox.value = minValue;
							return false;
						} else {
							amountBox.style.border = "";
						}

						// Start Processing
						var anchorElement = this.querySelector('a');
						if (anchorElement) {
							anchorElement.innerText = "...";
						}

						var xhr = new XMLHttpRequest();
						xhr.open('POST', '<?php echo esc_url(admin_url('admin-ajax.php')); ?>', true);

						// Set up FormData
						var formData = new FormData();
						formData.append('action', 'fundrizer_add_to_cart');
						formData.append('amount', amountBox.value);
						formData.append('pid', productId);
						formData.append('nonce', '<?php echo wp_create_nonce('frzr-add-to-cart'); ?>');

						xhr.onload = function() {
							if (xhr.status === 200) {
								var responseText = xhr.responseText;
								if (responseText.trim() === 'success') {
									window.location.href = '<?php echo esc_url(\wc_get_checkout_url()); ?>';
								}
							}
						};

						xhr.send(formData);

					});
				});
			});
		</script>
<?php
	}
}
