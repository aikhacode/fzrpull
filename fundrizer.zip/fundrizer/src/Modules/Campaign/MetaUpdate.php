<?php

namespace Fundrizer\Modules\Campaign;

use Fundrizer\Helper\Utils;

class MetaUpdate
{

	private $post_id;

	public function refresh(int $post_id): void
	{
		$this->post_id = $post_id;

		$this->raised();
		$this->goal();
		$this->progress();
		$this->deadline();
	}

	public function raised(): void
	{
		$amount = (int) get_post_meta($this->post_id, 'raised', true);

		$display = Utils::currency_format($amount);
		update_post_meta($this->post_id, 'raised_display', $display);
	}

	public function goal(): void
	{
		$amount = (int) get_post_meta($this->post_id, 'goal', true);
		$display = Utils::currency_format($amount);
		update_post_meta($this->post_id, 'goal_display', $display);
	}

	public function progress(): void
	{
		$raised = (int) get_post_meta($this->post_id, 'raised', true);
		$goal = (int) get_post_meta($this->post_id, 'goal', true);

		if ($goal === 0) {
			update_post_meta($this->post_id, 'progress_percentage', 0);
		} else {
			$calculated = round($raised / $goal * 100, 2);
			update_post_meta($this->post_id, 'progress_percentage', $calculated);
		}
	}

	public function deadline(): void
	{
		$deadline = get_post_meta($this->post_id, 'deadline', true);
		if (empty($deadline)) {
			update_post_meta($this->post_id, 'deadline_display', "∞");
		} else {
			$time = human_time_diff(time(), strtotime($deadline));
			update_post_meta($this->post_id, 'deadline_display', $time);
		}
	}
}
