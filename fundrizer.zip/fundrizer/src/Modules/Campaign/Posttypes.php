<?php

namespace Fundrizer\Modules\Campaign;

use Error;
use JsonException;

class Posttypes
{

	private static $registered = false;

	public static function register()
	{
		if (self::$registered) {
			return;
		}

		// Register campaign post type
		register_post_type(
			'frzr_campaign',
			array(
				'labels' => array(
					'name'          => __('Campaigns', 'fundrizer'),
					'singular_name' => __('Campaign', 'fundrizer'),
					'menu_name'     => __('Campaigns', 'fundrizer'),
					'add_new'       => __('New Campaign', 'fundrizer'),
					'add_new_item'  => __('New Campaign', 'fundrizer'),
					'new_item'      => __('New Campaign', 'fundrizer'),
					'edit_item'     => __('Edit Campaign', 'fundrizer'),
					'view_item'     => __('View Campaign', 'fundrizer'),
					'all_items'     => __('All Campaigns', 'fundrizer'),
				),
				'public' => true,
				'menu_icon' => 'dashicons-megaphone',
				'supports' => array('title', 'editor', 'thumbnail', 'custom-fields', 'excerpt', 'comments'),
				'has_archive' => true,
				'rewrite' => array('slug' => 'campaign'),
				'show_in_rest' => true,
				'show_in_menu' => false,
				'show_in_admin_bar' => true
			)
		);

		// Register campaign-update post type
		register_post_type(
			'frzr_campaign_update',
			array(
				'labels' => array(
					'name' => __('Campaign Update', 'fundrizer'),
					'singular_name' => __('Campaign Update', 'fundrizer'),
					'menu_name' => __('Campaigns Update', 'fundrizer'),
				),
				'public' => true,
				'hierarchical' => true,
				'menu_icon' => 'dashicons-megaphone',
				'supports' => array('title', 'editor', 'thumbnail', 'custom-fields'),
				'has_archive' => true,
				'rewrite' => array('slug' => 'campagin/update', 'with_front' => false),
				'show_in_rest' => true,
				'show_in_menu' => false,
			)
		);

		add_filter('rwmb_meta_boxes', function ($meta_boxes) {
			$meta_boxes[] = [
				'id'         => 'fundraising-metric',
				'title'      => 'Fundraising Metric',
				'post_types' => 'frzr_campaign',
				'fields'     => [
					[
						'id'   => 'goal',
						'name' => __('Goal', 'fundrizer'),
						'type' => 'currency',
					],
					[
						'id'   => 'deadline',
						'name' => __('Deadline', 'fundrizer'),
						'type' => 'datetime',
					]
				],
			];
			return  $meta_boxes;
		});

		self::$registered = true;
	}
}
